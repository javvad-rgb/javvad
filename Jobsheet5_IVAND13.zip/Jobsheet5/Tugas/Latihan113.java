import java.util.Scanner;
public class Latihan113 {
    public static void main() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Masukkan bil1 : ");
        int bil1 = sc.nextInt();
        System.out.println("Masukkan bil2 : ");
        int bil2 = sc.nextInt();
        System.out.println("Masukkan bil3 : ");
        int bil3 = sc.nextInt();

        if (bil1 > bil2) {
            if (bil1 > bil3){
                System.out.println("Bilangan terbesar : " + bil1);
            } else {
                System.out.println("Bilangan terbesar : " + bil3);
            } 
        } else {
                if (bil2 > bil3) {
                    System.out.println("Bilangan terbesar : " + bil2);
                } else {
                    System.out.println("Bilangan terbesar : " + bil3);
            }
        }
        sc.close();
    }
}
