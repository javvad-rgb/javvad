import java.util.Scanner;
public class Latihan213 {
    public static void main() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Masukkan tipe kamus/novel/lainnya : ");
        String tipebuku = sc.nextLine();
        System.out.println("Masukkan jumlah : ");
        int jumlah = sc.nextInt();

        double diskon = 0;

        if (tipebuku.equalsIgnoreCase("kamus")) {
            diskon = 0.10;
            if (jumlah > 2) {
                diskon += 0.02;
            }  
        } else if (tipebuku.equalsIgnoreCase("novel")) {
            diskon = 0.07;
            if (jumlah > 3) {
                diskon += 0.02;
            } else {
                diskon += 0.01;
            }
        } else {
            if (jumlah > 3) {
                diskon = 0.05;
            } else {
                diskon = 0;
            }
        }

        System.out.println("Jumlah diskon = " + (diskon * 100) + "%");

        sc.close();
    }    
}