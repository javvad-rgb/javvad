import java.util.Scanner;
public class Pemilihan2Percobaan213 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int menu;
        String member;
        double harga = 0, totalbayar = 0, diskon = 0;

        System.out.println("-------------------------");
        System.out.println("===== MENU KAFE JTI =====");
        System.out.println("-------------------------");
        System.out.println("1. Ricebowl");
        System.out.println("2. Ice Tea");
        System.out.println("3. Paket Bundling (Ricebowl + Ice Tea)");
        System.out.println("------------------------------------");
        System.out.print("Masukkan angka dari menu yang dipilih : ");
        
        menu = sc.nextInt();
        sc.nextLine();
        System.out.print("Apakah punya member (y/n) : ");
        member = sc.nextLine();
        System.out.println("------------------------------------");

        if (member.equalsIgnoreCase("y")){
            diskon = 0.10;
            System.out.println("Besar diskon = 10%");
            if (menu == 1){
                harga = 14000;
                System.out.println("Harga Ricebowl : " + harga);
            }
            else if (menu == 2){
                harga = 3000;
                System.out.println("Harga Ice Tea : " + harga);
            }
            else if (menu == 3){
                harga = 15000;
                System.out.println("Harga Bundling : " + harga);
            }
            else {
                System.out.println("Masukkan pilihan menu dengan benar : ");
                return;
            }

            totalbayar = harga - (harga * diskon);
            System.out.println("Total bayar setelah diskon = " + totalbayar);
        }

        else if (member.equalsIgnoreCase("n")){
            if (menu == 1){
                harga = 14000;
                System.out.println("Harga Ricebowl : " + harga);
            }
            else if (menu == 2){
                harga = 3000;
                System.out.println("Harga Ice Tea : " + harga);
            }
            else if (menu == 3){
                harga = 15000;
                System.out.println("Harga Bundling : " + harga);
            }
            else {
                System.out.println("Masukkan pilihan menu dengan benar : ");
                return;
            }

            System.out.println("Total bayar = " + harga);
        
        } else {
                System.out.println("Member tidak valid");
            }

            System.out.println("--------------------");
            sc.close();
    }
}