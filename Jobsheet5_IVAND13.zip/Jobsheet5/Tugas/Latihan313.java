import java.util.Scanner;

public class Latihan313 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Masukkan brand sepatu (Converse / Sketcher / Nike) : ");
        String brand = sc.nextLine();
        System.out.print("Masukkan kategori sepatu : ");
        String kategori = sc.nextLine();
        System.out.print("Masukkan ukuran sepatu : ");
        int ukuran = sc.nextInt();

        double harga = 0;
        boolean statusValid = true;

        if (brand.equalsIgnoreCase("Converse")) {
            if (kategori.equalsIgnoreCase("Slip On")) {
                harga = 800000;
            } else if (kategori.equalsIgnoreCase("High Top")) {
                harga = 1200000;
            } else {
                statusValid = false;
            }
        } else if (brand.equalsIgnoreCase("Sketcher")) {
            if (kategori.equalsIgnoreCase("Woman")) {
                harga = 1000000;
            } else if (kategori.equalsIgnoreCase("Man")) {
                harga = 1800000;
            } else {
                statusValid = false;
            }
        } else if (brand.equalsIgnoreCase("Nike")) {
            if (kategori.equalsIgnoreCase("Kids")) {
                harga = 750000;
            } else if (kategori.equalsIgnoreCase("Adult")) {
                harga = 1500000;
            } else {
                statusValid = false;
            }
        } else {
            statusValid = false;
        }

        if (statusValid) {
            System.out.println("Harga sepatu yang harus dibayar: Rp " + harga);
        } else {
            System.out.println("Merk atau kategori sepatu tidak ditemukan / tidak valid.");
        }

        sc.close();
    }
}